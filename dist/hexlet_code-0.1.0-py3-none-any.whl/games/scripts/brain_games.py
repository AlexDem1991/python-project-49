from games import cli


def greet():
    """greeting user"""
    print("Welcome to the Brain Games!")


def main():
    greet()


if __name__ == "__main__":
    main()
    cli.main()
