### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexDem1991/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AlexDem1991/python-project-49/actions)
https://asciinema.org/a/uHis5JDgSGugLINgnsDMWM4Tm
