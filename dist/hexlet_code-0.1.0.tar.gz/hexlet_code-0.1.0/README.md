### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexDem1991/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AlexDem1991/python-project-49/actions)
https://asciinema.org/a/uHis5JDgSGugLINgnsDMWM4Tm
https://asciinema.org/a/vdh9kEStbB8d3WRnrAVBeX6Z3
https://asciinema.org/a/ctrRYNRmgwkukWc8trQS6vOhi
https://asciinema.org/a/UPt7PCIj3lrVNGIY8ZrkphS62
https://asciinema.org/a/ggDyXZm9ybGyQ8d5VhDnuEOrM